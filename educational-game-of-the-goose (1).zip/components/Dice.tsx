
import React from 'react';

interface DiceProps {
  value: number | null;
  rolling: boolean;
  onRoll: () => void;
  disabled?: boolean;
}

const Dice: React.FC<DiceProps> = ({ value, rolling, onRoll, disabled }) => {
  const dots = {
    1: [4],
    2: [0, 8],
    3: [0, 4, 8],
    4: [0, 2, 6, 8],
    5: [0, 2, 4, 6, 8],
    6: [0, 2, 3, 5, 6, 8],
  };

  const currentDots = value ? dots[value as keyof typeof dots] : [];

  return (
    <button 
      onClick={onRoll}
      disabled={rolling || disabled}
      className={`relative w-28 h-28 bg-white rounded-[1.5rem] shadow-[0_15px_30px_-5px_rgba(0,0,0,0.1),0_10px_10px_-5px_rgba(0,0,0,0.04)] border-b-8 border-slate-200 flex items-center justify-center p-5 transition-all
        ${rolling ? 'animate-bounce scale-110' : 'hover:scale-105 active:scale-95'}
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
      `}
    >
      <div className="grid grid-cols-3 grid-rows-3 w-full h-full gap-2">
        {Array.from({ length: 9 }).map((_, i) => (
          <div key={i} className="flex items-center justify-center">
            {currentDots.includes(i) && (
              <div className="w-5 h-5 bg-slate-800 rounded-full shadow-inner" />
            )}
            {rolling && Math.random() > 0.6 && (
                 <div className="w-5 h-5 bg-slate-200 rounded-full" />
            )}
          </div>
        ))}
      </div>
    </button>
  );
};

export default Dice;
