
import React, { useState } from 'react';
import { Question, Player } from '../types';

interface QuestionModalProps {
  question: Question;
  onAnswer: (correct: boolean) => void;
  player: Player;
}

const QuestionModal: React.FC<QuestionModalProps> = ({ question, onAnswer, player }) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedIdx(idx);
    setIsAnswered(true);
    
    setTimeout(() => {
        onAnswer(idx === question.correctIndex);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-[100] p-6">
      <div className="bg-white w-full max-w-2xl rounded-[3rem] overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300 border-8 border-white">
        <div 
            className="p-8 text-white text-center flex flex-col items-center"
            style={{ backgroundColor: player.color }}
        >
          <div className="text-5xl mb-3 filter drop-shadow-lg">{player.icon}</div>
          <h2 className="text-2xl font-black font-fredoka uppercase tracking-wider">Sfida per {player.name}</h2>
        </div>
        
        <div className="p-10">
          <p className="text-2xl font-bold text-slate-800 mb-10 text-center leading-relaxed">{question.text}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {question.options.map((option, idx) => {
              let btnClass = "p-5 rounded-3xl border-4 transition-all text-left font-bold text-lg ";
              
              if (isAnswered) {
                if (idx === question.correctIndex) {
                  btnClass += "bg-emerald-100 border-emerald-500 text-emerald-800 scale-105";
                } else if (idx === selectedIdx) {
                  btnClass += "bg-rose-100 border-rose-500 text-rose-800";
                } else {
                  btnClass += "bg-slate-50 border-slate-100 opacity-50";
                }
              } else {
                btnClass += "bg-white border-slate-100 hover:border-indigo-400 hover:bg-indigo-50 hover:-translate-y-1 shadow-sm";
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  className={btnClass}
                  disabled={isAnswered}
                >
                  <span className="inline-block w-8 h-8 rounded-full bg-slate-100 text-center leading-8 mr-4 font-black text-slate-500">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  {option}
                </button>
              );
            })}
          </div>
        </div>

        {isAnswered && (
          <div className={`p-6 text-center font-black text-xl animate-bounce uppercase tracking-widest ${selectedIdx === question.correctIndex ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
            {selectedIdx === question.correctIndex ? "Corretto! Sei un genio! ✅" : "Sbagliato! Ritenta... ❌"}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuestionModal;
