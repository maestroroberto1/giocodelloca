
import React from 'react';
import { Tile, Player, TileType } from '../types';
import { SPECIAL_TILES, TILE_COLORS } from '../constants';

interface BoardProps {
  tiles: Tile[];
  players: Player[];
}

const Board: React.FC<BoardProps> = ({ tiles, players }) => {
  const cols = 12;
  const rows = 8;

  // Manual mapping to create the spiral layout from the reference image
  const getTilePosition = (index: number) => {
    if (index <= 11) return { r: 7, c: index };
    if (index <= 18) return { r: 7 - (index - 11), c: 11 };
    if (index <= 30) return { r: 0, c: 11 - (index - 19) };
    if (index <= 35) return { r: index - 30, c: 0 };
    if (index <= 43) return { r: 5, c: index - 36 + 2 };
    if (index <= 47) return { r: 5 - (index - 43), c: 9 };
    return { r: 4, c: 5 };
  };

  const boardGrid = Array.from({ length: rows }, () => Array(cols).fill(null));
  tiles.forEach((tile, idx) => {
    const pos = getTilePosition(idx);
    boardGrid[pos.r][pos.c] = tile;
  });

  return (
    <div className="relative bg-[#FFF9F0] p-4 rounded-[2rem] shadow-inner border-[12px] border-[#D97706] max-w-5xl w-full select-none">
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0 opacity-10 md:opacity-100">
        <div className="text-center p-10 transform -rotate-12">
            <h2 className="text-5xl font-black text-[#1E3A8A] font-fredoka leading-none">Gioco dell'Oca</h2>
            <p className="text-2xl text-[#D97706] font-bold uppercase tracking-wider">Ecologico</p>
            <div className="text-9xl mt-4">🪿</div>
        </div>
      </div>

      <div className="grid grid-cols-12 grid-rows-8 gap-1 relative z-10">
        {boardGrid.map((row, rIdx) => 
          row.map((tile: Tile | null, cIdx) => {
            if (!tile) return <div key={`empty-${rIdx}-${cIdx}`} className="aspect-square" />;
            
            const isSpecial = SPECIAL_TILES[tile.index];
            const tileColor = TILE_COLORS[tile.index % TILE_COLORS.length];
            const playersHere = players.filter(p => p.position === tile.index);

            return (
              <div 
                key={`tile-${tile.index}`}
                style={{ backgroundColor: tileColor }}
                className={`relative aspect-square border-[1px] border-white/30 flex flex-col items-center justify-center shadow-sm 
                  ${tile.index === 0 ? 'rounded-bl-xl' : ''}
                  ${tile.index === 11 ? 'rounded-br-xl' : ''}
                  ${tile.index === 19 ? 'rounded-tr-xl' : ''}
                  ${tile.index === 30 ? 'rounded-tl-xl' : ''}
                  overflow-hidden group transition-all duration-300
                `}
              >
                <span className={`absolute top-1 left-1 text-[10px] md:text-xs font-black ${tileColor === '#FBBF24' ? 'text-slate-800' : 'text-white'} opacity-60`}>
                  {tile.index + 1}
                </span>

                <div className="flex flex-col items-center justify-center">
                  {isSpecial ? (
                    <span className="text-xl md:text-3xl filter drop-shadow-md transform group-hover:scale-110 transition-transform">
                      {isSpecial.icon}
                    </span>
                  ) : (
                    <span className={`text-lg md:text-xl font-black ${tileColor === '#FBBF24' ? 'text-slate-800' : 'text-white'}`}>
                      {tile.index + 1}
                    </span>
                  )}
                </div>

                {/* Animated Player Pawns (Animals) */}
                <div className="absolute inset-0 flex items-center justify-center gap-0.5 pointer-events-none p-1 flex-wrap content-center">
                  {playersHere.map(p => (
                    <div 
                      key={p.id}
                      className="w-6 h-6 md:w-9 md:h-9 rounded-full border-2 border-white shadow-xl animate-bounce z-50 transition-all duration-500 flex items-center justify-center text-sm md:text-xl"
                      style={{ 
                        backgroundColor: p.color,
                        boxShadow: `0 4px 10px rgba(0,0,0,0.3), inset 0 0 10px rgba(255,255,255,0.3)`
                      }}
                    >
                      {p.icon}
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Board;
