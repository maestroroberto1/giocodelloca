
import React from 'react';

interface HistoryLogProps {
  history: string[];
}

const HistoryLog: React.FC<HistoryLogProps> = ({ history }) => {
  return (
    <div className="flex-1 bg-white p-6 rounded-3xl shadow-sm overflow-hidden flex flex-col">
      <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
        <span className="mr-2">📝</span> Cronologia Mosse
      </h3>
      <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
        {history.map((item, idx) => (
          <div 
            key={idx} 
            className={`p-3 rounded-xl text-sm animate-in slide-in-from-right duration-300 ${idx === 0 ? 'bg-indigo-50 border-l-4 border-indigo-500 font-medium' : 'bg-slate-50 text-slate-600'}`}
          >
            {item}
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoryLog;
