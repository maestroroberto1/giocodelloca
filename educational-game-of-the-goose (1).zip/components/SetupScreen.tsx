
import React, { useState } from 'react';

interface SetupScreenProps {
  onStart: (topic: string, ageGroup: string, playerCount: number) => void;
}

const SetupScreen: React.FC<SetupScreenProps> = ({ onStart }) => {
  const [topic, setTopic] = useState('Storia dell\'Antica Roma');
  const [ageGroup, setAgeGroup] = useState('8-10 anni');
  const [playerCount, setPlayerCount] = useState(2);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim()) {
      onStart(topic, ageGroup, playerCount);
    }
  };

  return (
    <div className="min-h-screen bg-indigo-600 flex items-center justify-center p-6">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl p-8 animate-in slide-in-from-bottom duration-500">
        <div className="text-center mb-8">
            <span className="text-6xl">🪿</span>
            <h1 className="text-4xl font-bold text-indigo-900 mt-4 font-fredoka">Il Gioco dell'Oca</h1>
            <p className="text-slate-500 mt-2">Personalizza la tua avventura didattica</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Qual è l'argomento?</label>
            <input 
              type="text" 
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="es. Matematica, Sistema Solare..."
              className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-indigo-500 focus:outline-none transition"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Età dei giocatori?</label>
            <select 
              value={ageGroup}
              onChange={(e) => setAgeGroup(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-indigo-500 focus:outline-none transition"
            >
              <option>6-7 anni</option>
              <option>8-10 anni</option>
              <option>11-13 anni</option>
              <option>14+ anni</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Quanti giocatori?</label>
            <div className="flex gap-4">
              {[2, 3, 4].map(n => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setPlayerCount(n)}
                  className={`flex-1 py-3 rounded-xl font-bold transition ${playerCount === n ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-emerald-600 transition transform hover:scale-105"
          >
            Inizia la Sfida!
          </button>
        </form>

        <p className="text-center text-xs text-slate-400 mt-8">
            Realizzato con Gemini AI per contenuti educativi dinamici.
        </p>
      </div>
    </div>
  );
};

export default SetupScreen;
