
import { GoogleGenAI, Type } from "@google/genai";
import { Question } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateEducationalQuestions = async (topic: string, ageGroup: string): Promise<Question[]> => {
  const prompt = `Genera 20 domande a risposta multipla sull'argomento "${topic}" adatte a bambini/ragazzi di età "${ageGroup}". 
  Ogni domanda deve avere 4 opzioni di cui una sola corretta. 
  Le domande devono essere divertenti ed educative.
  Assicurati che il linguaggio sia appropriato per l'età specificata.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING, description: "Il testo della domanda" },
            options: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Array di 4 possibili risposte" 
            },
            correctIndex: { type: Type.INTEGER, description: "L'indice (0-3) della risposta corretta" }
          },
          required: ["text", "options", "correctIndex"]
        }
      }
    }
  });

  const rawQuestions = JSON.parse(response.text);
  return rawQuestions.map((q: any, idx: number) => ({
    ...q,
    id: `q-${idx}`
  }));
};
